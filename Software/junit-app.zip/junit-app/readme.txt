This is a simple Java application with JUnit tests.
JUnit is a simple framework to write repeatable tests (http://junit.org/).


Instructions using Maven:
------------------------

To use JUnit in Maven, it is necessary to put the test classes under src/test/java.
It is also necessary to add the following dependency:
    <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>4.12</version>
        <scope>test</scope>
    </dependency>
Note that the element <version> can be updated to the desired JUnit version.
The scope says that the library should only be used for testing.

The following configuration copies resource files to target and
the filtering option replaces ${property} by the respective values
    <testResources>
        <testResource>
            <directory>src/test/resources</directory>
            <filtering>true</filtering>
        </testResource>
    </testResources>

To compile:
  mvn compile

To test:
  mvn test

To run using exec plugin:
  mvn exec:java

To generate launch scripts for Windows and Linux:
  (appassembler:assemble is attached to install phase)
  mvn install

To run using appassembler plugin:
  On Windows:
    target\appassembler\bin\junit-app
  On Linux:
    ./target/appassembler/bin/junit-app


To configure the Maven project in Eclipse:
-----------------------------------------

'File', 'Import...', 'Maven'-'Existing Maven Projects'
'Select root directory' and 'Browse' to the project base folder.
Check that the desired POM is selected and 'Finish'.


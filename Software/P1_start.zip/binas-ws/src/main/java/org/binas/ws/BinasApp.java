package org.binas.ws;

public class BinasApp {

	public static void main(String[] args) throws Exception {
		System.out.println(BinasApp.class.getSimpleName() + " running");
		// TODO
	}

}
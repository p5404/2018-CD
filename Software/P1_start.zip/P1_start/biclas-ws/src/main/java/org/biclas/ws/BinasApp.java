package org.biclas.ws;

public class biclasApp {

	public static void main(String[] args) throws Exception {
		System.out.println(biclasApp.class.getSimpleName() + " running");
		// TODO
	}

}
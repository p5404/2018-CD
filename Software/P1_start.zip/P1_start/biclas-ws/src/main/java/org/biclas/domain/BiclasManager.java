package org.biclas.domain;

public class BiclasManager {

	// Singleton -------------------------------------------------------------

	private BiclasManager() {
	}

	/**
	 * SingletonHolder is loaded on the first execution of Singleton.getInstance()
	 * or the first access to SingletonHolder.INSTANCE, not before.
	 */
	private static class SingletonHolder {
		private static final BiclasManager INSTANCE = new BiclasManager();
	}

	public static synchronized BiclasManager getInstance() {
		return SingletonHolder.INSTANCE;
	}

	
	// TODO

}
